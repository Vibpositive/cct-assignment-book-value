/**
 * @Author: vibpositive
 * @Date:   2017-03-18T18:50:46+00:00
 * @Last modified by:   vibpositive
 * @Last modified time: 2017-03-18T20:50:17+00:00
 */

$( document ).ready(function() {
    $(".nav-column-logo").click(function(){
      $(location).attr('href','http://bookvaluedublin.000webhostapp.com/');
    });
});
